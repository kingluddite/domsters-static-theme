<?php if ( ! dynamic_sidebar( 'page' ) ): ?>
  <!-- if no sidebar, show this content -->
  <h3>Set Up this sidebar</h3>
  <p>Drag content here so your sidebar wont be empty</p>
<?php endif; ?>
