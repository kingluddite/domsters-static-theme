  <footer> <p>&copy; <?php bloginfo('name'); ?> <?php echo date('Y'); ?></footer>
  <?php wp_footer(); ?>
</body>
</html>
